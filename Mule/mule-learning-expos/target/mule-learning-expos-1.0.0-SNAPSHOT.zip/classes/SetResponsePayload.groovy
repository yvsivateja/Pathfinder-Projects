package groovy
import groovy.xml.MarkupBuilder

def writer = new StringWriter()
def out = new MarkupBuilder(writer)


/*System.out.println(" Response Payload" +message.getInvocationProperty('responsePayload'))*/

System.out.println("  Payload" +payload.toString())


out."soapenv:Envelope"("xmlns:soapenv": "http://schemas.xmlsoap.org/soap/envelope/","xmlns:v1":"http://www.genesisenergy.co.nz/esb/financial/getAccountEvent/v1"){
	"soapenv:Header"{}
	"soapenv:Body"{
		"v1:getAccountEventResponse" {
			"responseStatus"()
			"getAccountEventResponseResult"{
				payload.each{dbRow->
				   "accountEvent"{
					   "id"(dbRow['id'])
				   	   "name"(dbRow['name'])
					   	
					}				
				}
				
					
			}
		}
	}
}


return writer.toString()